use classicmodels;
select * from customers;

     -- day 3 (1)
     
select customernumber,customername,state,creditlimit from customers where state is not null and
creditlimit between 50000 and 100000 order by creditlimit desc;

     -- day 3 (2)
     
select distinct productline from products where productLine like "%cars";

     -- day 4 (1)
     
select orderNumber,status, ifnull(comments,"-") as "comments" from orders where status = "shipped";

      -- day 4 (2)
      
select employeenumber, firstName, jobTitle, case jobTitle when "President" then "P"
WHEN "Sales Manager (APAC)" THEN "SM" WHEN  "Sale Manager (EMEA)" THEN "SM"
WHEN  "Sales Manager (NA)" THEN "SM" 
WHEN  "Sales Rep" THEN "SR" WHEN "VP Sales" THEN "VP" WHEN "VP Marketing" THEN "VP"
END AS "JOB_TITLE_ABR" from employees;

   -- day5 (1)
   
   select distinct 
year(paymentDate) as Year , min(amount) as "Min Amount"
from classicmodels.payments
group by year(paymentDate)
order by year ;
 
    -- day5 (2)
    
    select distinct
  year(orderDate) as Year,
  concat("Q",quarter(orderDate)) as Quarter, 
  count(distinct customerNumber) as "Unique customers", 
  count(orderNumber) as "Total Orders"
 from classicmodels.orders
 group by year(orderDate) ,Quarter;
 
 
     -- Day5 (3)
     
      select distinct 
 monthname(paymentDate) as month,
 concat(format(sum(amount)/1000,0),"K") as form_Amount
 from classicmodels.payments
 group by monthname(paymentDate)
 having sum(amount) between 500000 and 1000000
 order by sum(amount) desc;
     
-- Day6 (1)

Create Table Journey(Bus_ID int NOT NULL, 
                     Bus_name Char(30) Not Null,
                     Source_station Char(20) Not Null,
					 Destination Char(20) Not Null,
                     Email Varchar(30) unique) ;
                     
-- Day6 (2)

Create Table Vendor(Vendor_ID int NOT NULL Unique, 
					Vendor_Name Char(30) Not Null,
                    Email Varchar(30) unique,
                    Country Char(20) Default "N/A");
                    
-- Day6 (3)

Create Table Movies(Movie_ID Int NOT NULL Unique, 
					Movie_name Char(30) Not Null,
                    Release_Year Char(4) default "-",
                    Cast_Name Varchar(50) Not Null,
                    Gender Char(10), Check (Gender = "Male" or "Female"),
                    No_of_Shows Int,
                    Constraint onlypositive check (No_of_Shows >= 0)) ;
                    
-- Day6 (4)

Create Table Supplier(Supplier_ID INT Primary Key,
                      Supplier_name Char(30),
                      Location Char(20));
                      
Create Table Product(Product_ID INT Primary Key,
                     Product_Name Char(30) Not Null Unique,
                     Descriptions Varchar(50),
                     Supplier_ID INT,
                     FOREIGN KEY (Supplier_ID) REFERENCES Supplier(Supplier_ID)) ;
		
Create Table Stock(Stock_ID INT Primary Key,
				   Product_ID INT,
				   Balance_Stock INT,
                   FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID));

      -- Day7 (1)
      
select e.employeeNumber,concat(e.firstname," ",e.lastname) as "sales person",
count(distinct c.customernumber) as "unique customer"
from employees as e inner join customers as c on c.salesRepEmployeeNumber=e.employeeNumber
group by employeeNumber
order by count(distinct c.customernumber) desc;

   -- day7 (2)
   
 select c.customernumber, c.customername, p.productCode, p.productName,
 od.quantityOrdered as "ordered Qty", p.quantityInStock as "Total Inventory", (p.quantityInStock-od.quantityOrdered) as "Left Qty"
 from customers as c inner join orders as o on c.customerNumber=o.customerNumber
 inner join orderdetails as od on o.orderNumber= od.orderNumber 
 inner join products as p on od.productCode = p.productCode 
 order by c.customernumber, p.productcode;
 
 -- day7 (3)
 
 Create table laptop(Laptop_name varchar(20));
 Create table colour(Colour_name varchar(20));
  
Insert into laptop values("Dell"), ("HP");
Insert into Colour values("White"), ("Silver"),("Black");

select * from laptop;
select * from colour ;
select L.Laptop_name as "Laptop Name", c.Colour_name as "Colour Name" 
from laptop L cross join colour C order by L.laptop_NAME;

-- day7 (4)

Create Table Project(EmployeeID INT,
                     FullName Char(30),
                     Gender Char(6),
                     ManagerID INT);
                     
INSERT INTO Project VALUES(1, 'Pranaya', 'Male', 3);
INSERT INTO Project VALUES(2, 'Priyanka', 'Female', 1);
INSERT INTO Project VALUES(3, 'Preety', 'Female', NULL);
INSERT INTO Project VALUES(4, 'Anurag', 'Male', 1);
INSERT INTO Project VALUES(5, 'Sambit', 'Male', 1);
INSERT INTO Project VALUES(6, 'Rajesh', 'Male', 3);
INSERT INTO Project VALUES(7, 'Hina', 'Female', 3);

Select * from Project;

Select M.Fullname as "Manager Name", E.Fullname as "Employee Name"
from Project E Inner Join Project M on E.ManagerID = M.EmployeeID ;

-- Day8 

Create Table Facility(Facility_ID Int Not Null,
                      Facility_Name Varchar(100),
                      State Varchar(100),
                      Country Varchar(100)) ;
                      
Alter Table Facility modify Column Facility_ID INT Primary Key Auto_Increment ;

Desc Facility;

Alter Table Facility Add Column City Varchar(100) after Facility_Name;
Alter Table Facility Modify Column City Varchar(100) NOT NULL after Facility_Name; 

Desc Facility;

--  DAY 9

Create Table University(ID INT, 
                        University_Name Varchar(50));
                        
INSERT INTO University(ID,University_Name) 
VALUES (1, "       Pune          University     "), 
               (2, "  Mumbai          University     "),
              (3, "     Delhi   University     "),
              (4, "Madras University"),
              (5, "Nagpur University");

Select * from university;
              
Select ID,(Replace(University_Name," ","")) from University;
					
 SELECT ID, Trim(REGEXP_REPLACE(University_Name, '[ ]+', ' ')) AS Name
FROM University;

 -- DAY 10
 
 create view product_status as select year(o.orderdate) as "year",
 concat(count(od.quantityordered)," ","(",round(((count(*)/(select count(*) from orderdetails))*100),0),'%',")") as "value"
from orders as o inner join orderdetails as od on o.ordernumber=od.ordernumber group by year(o.orderdate) ;
select * from product_status; 

-- day 11(1)


DELIMITER //

CREATE PROCEDURE GetCustomerLevel (
    IN Cust INT
)
BEGIN
    DECLARE Lct_creditlimit int;

    SELECT creditlimit into lct_creditlimit from Customers where customernumber = CUST;
        CASE
            WHEN lct_creditLimit > 100000 THEN select 'Platinum';
            WHEN lct_creditLimit BETWEEN 25000 AND 100000 THEN select 'Gold';
            WHEN lct_creditLimit < 25000 THEN select 'Silver';
            ELSE select 'Unknown';
	
    end case;
END //

DELIMITER ;

-- day 11(2)

DELIMITER //

CREATE PROCEDURE Get_country_payments(in inout_year int, in input_country varchar(255))
    
BEGIN
    SELECT 
       year(paymentdate) as year,
       country as Country,
       concat(format(sum(amount) / 1000,0), 'K') as Totalamount
       from payments
       inner join CUSTOMERS ON PAYMENTS.customerNumber = CUSTOMERS.customerNumber
       where year (paymentdate) = inout_year
       and country = input_country
       group by year, Country;
END //

DELIMITER ;

 -- day 12 (1)
  select Year(orderDate) as year,monthname(orderdate) as month ,count(*) as "Total Orders",
concat(
format(
(count(*)-lag(count(*)) over ( order by year(orderdate) ))/lag(count(*)) over ( order by year(orderdate) )*100
,0),
"%") as "% YoY change"
from classicmodels.orders
group by Year(orderDate),monthname(orderdate);
 
 
   -- day 12 (2)
   create table Emp_udf(
Emp_id int primary key auto_increment,
name varchar(50),
DOB date);

INSERT INTO Emp_UDF(Name, DOB)
VALUES ("Piyush", "1990-03-30"), ("Aman", "1992-08-15"), ("Meena", "1998-07-28"), ("Ketan", "2000-11-21"), ("Sanjay", "1995-05-21");


select Emp_id,Name, DOB,Calculate_age(dob) as age from classicmodels.emp_udf;

-- calculate_age function script
/*
CREATE DEFINER=`root`@`localhost` FUNCTION `Calculate_age`(Dob date) RETURNS varchar(50) CHARSET latin1
BEGIN
declare y varchar(50);
select datediff(curdate(),Dob) into y;
set y = concat(format(y/365,0)," Years ",format(y%365/30,0), " months");
RETURN y;
END   */

-- day 13(1)

select * from Customers; 
select * from Orders; 
select customernumber, customername from customers where customernumber
not in (select customernumber from orders);

-- day 13(2)
select c.customerNumber,c.customername,count(o.orderNumber) 
from customers as c left join orders as o 
on c.customerNumber=o.customerNumber group by c.customerNumber
union select o.customerNumber,c.customername,o.orderNumber from orders as o
right join customers as c on c.customerNumber=o.customerNumber;
 
-- day13 (3)
 
 WITH Quant as 
 (select orderNumber as "Order_Number" ,quantityOrdered "Quantity_Ordered", 
 dense_rank() over(partition by orderNumber order by quantityOrdered desc ) as "Quantity_Rank"
from orderdetails) 
select Order_Number, Quantity_Ordered from Quant where Quantity_Rank = 2;
 
 -- Day 13 (4) 
 
 WITH Counter as (
 select ordernumber, count(quantityordered) as "Order_count" from orderdetails
 group by ordernumber) 
 select max(Order_count), min(order_count) from Counter ;
 
 -- Day 13 (5) 
 
 select p1.productline, count(productline)  from products p1
 WHERE BUYPRICE > ( SELECT AVG(buyPrice) FROM products p2 ) 
 group by productLINE order by count(productline) desc; 
  
 
    -- day 14

CREATE TABLE Emp_EH (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(255),
    EmailAddress VARCHAR(255)
);

-- Create stored procedure to insert values into Emp_EH with exception handling
DELIMITER //

CREATE PROCEDURE InsertEmpEH(
    IN p_EmpID INT,
    IN p_EmpName VARCHAR(255),
    IN p_EmailAddress VARCHAR(255)
)
BEGIN
    DECLARE error_occurred BOOLEAN DEFAULT FALSE;

    -- Exception handling
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        SET error_occurred = TRUE;
    END;

    -- Insert values into Emp_EH
    INSERT INTO Emp_EH (EmpID, EmpName, EmailAddress)
    VALUES (p_EmpID, p_EmpName, p_EmailAddress);

    -- Check for errors and display message
    IF error_occurred THEN
        SELECT 'Error occurred' AS ErrorMessage;
    ELSE
        SELECT 'Values inserted successfully' AS SuccessMessage;
    END IF;
END //

DELIMITER ;


     -- day 15
     

CREATE TABLE Emp_BIT (
    Name VARCHAR(255),
    Occupation VARCHAR(255),
    Working_date DATE,
    Working_hours INT
);


INSERT INTO Emp_BIT VALUES
('Robin', 'Scientist', '2020-10-04', 12),  
('Warner', 'Engineer', '2020-10-04', 10),  
('Peter', 'Actor', '2020-10-04', 13),  
('Marco', 'Doctor', '2020-10-04', 14),  
('Brayden', 'Teacher', '2020-10-04', 12),  
('Antonio', 'Business', '2020-10-04', 11); 


DELIMITER //

CREATE TRIGGER BeforeInsertEmpBIT
BEFORE INSERT ON Emp_BIT
FOR EACH ROW
BEGIN
    IF NEW.Working_hours < 0 THEN
        SET NEW.Working_hours = ABS(NEW.Working_hours);
    END IF;
END //

DELIMITER ;
  
  




 
